class Api::V1::Accounts::Contacts::ConversationsController < Api::V1::Accounts::Contacts::BaseController
  def index
    @conversations = @contact.conversations.where(account_id: current_account.id)

    unless Current.user.administrator? || user_has_permission?('conversation_manage')
      @conversations = @conversations.accessible_by_user(Current.user)
    end
    @conversations = @conversations.order(updated_at: :desc)

  end

  private

  def user_has_permission?(permission)
    account_user = Current.user.account_users.find_by(account_id: current_account.id)
    account_user&.administrator? || account_user&.custom_role&.permissions&.include?(permission)
  end

  def inbox_ids
    if Current.user.administrator? || Current.user.agent?
      Current.user.assigned_inboxes.pluck(:id)
    else
      []
    end
  end
end
